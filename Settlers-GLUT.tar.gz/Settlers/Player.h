/* 
 * File:   Player.h
 * Author: brandon
 *
 * Created on May 3, 2011, 10:00 PM
 */

#ifndef PLAYER_H
#define	PLAYER_H
#include "Road.h"
#include "Settlement.h"
#include "Board.h"
#include "Sprite.h"
#include "TradeOffer.h"

class Player {
public:
    Player(Vector3f color);
    Player(const Player& orig);
    virtual ~Player();
    void placeSettlement(int tile, int corner);
    void placeSettlement();
    void placeRoad();
    void placeRoad(int direction);
    bool isPlacingRoad();
    void upgradeSettlement();
    void Draw();
    void Update(int t);
    void select(int direction);
    void setBoard(Board* board);
    std::string getResourceString();
    int getResource(int resource);
    
    bool hasPort (int type);
    
    bool isNormalState();

    Vector3f getColor();

    Vector2f rollDice();
    
    bool endTurn();
    void beginTurn();
    
    void CollectResourcesOn(int num);
    
    void tradeResource(int resource);
    
    void reset();

private:
    bool isOnNetwork(Tile::CornerNode* node);
    bool startOfGame;
    bool rolled;
    bool currentPlayer;
    
    int state;
    std::string IntToStr(int n);
    Board* currentBoard; // current board in use

    int* resources;

    Tile::CornerNode* selection; // pointer to current node selection
    Sprite* selector; //visual representation of selection

    Road** roads; // array of pointers to all the roads placed
    int placedRoads; //number of placed roads
    int longestRoad;

    Settlement** settlements; // array of pointers to all settlements placed
    
    bool resourcePorts[5];
    bool standardPort;
    
    int placedSettlements; // all placed settlements
    int placedCities;
    
    Vector3f color; //player color

    int points;
    
    friend class TradeOffer;
};

#endif	/* PLAYER_H */

