/*
 * File:   TradeMenu.cpp
 * Author: brandon
 *
 * Created on May 19, 2011, 9:15 PM
 *
 * TODO: add create button. add current deals section with option to accept
 * Make selector look nicer
 */

#include "TradeMenu.h"
#include <sstream>

//TradeMenu::TradeMenu(std::string title) : Menu(title) {
//    state = VIEW_OFFERS;
//    offers = new TradeOffer*[MAX_OFFERS];
//    for (int i = 0; i < MAX_OFFERS; i++) {
//        offers[i] = NULL;
//    }
//    selector = new Sprite("tradeSelection.png");
//    memset(potentialOffer, 0, sizeof (potentialOffer));
//    currentSelection = 0;
//    currentOffer = 0;
//}

TradeMenu::TradeMenu() : Menu("Trade - View Offers") {
    currentPlayer = NULL;
    state = VIEW_OFFERS;
    offers = new TradeOffer*[MAX_OFFERS];
    for (int i = 0; i < MAX_OFFERS; i++) {
        offers[i] = NULL;
    }
    for (int i = 0; i < NUM_RESOURCES; i++) {
        resourceIcons[i] = new Sprite(getResourceString(i).append(".png"));
    }
    selector = new Sprite("tradeSelection.png");
    memset(potentialOffer, 0, sizeof (potentialOffer));
    currentSelection = 0;
    currentOffer = 0;
}

TradeMenu::TradeMenu(const TradeMenu& orig) {
    offers = new TradeOffer*[MAX_OFFERS];
    currentOffer = 0;
    currentSelection = 0;
}

TradeMenu::~TradeMenu() {
    delete offers;
}

void TradeMenu::select(int direction, Player* currentPlayer) {
    switch (direction) {
        case 0:
            if (state == CREATE && potentialOffer[currentSelection]>-9 && potentialOffer[currentSelection] > -currentPlayer->getResource(currentSelection))
                potentialOffer[currentSelection]--;
            break;
        case 1:
            if (state == CREATE)
                currentSelection = (currentSelection + 1) % NUM_RESOURCES;
            else if (offers[currentSelection + 1] != NULL)
                currentSelection++;
            break;
        case 2:
            if (state == CREATE && potentialOffer[currentSelection] < 9)
                potentialOffer[currentSelection]++;
            break;
        case 3:
            if (state == CREATE) {
                currentSelection = currentSelection - 1;
                if (currentSelection < 0)
                    currentSelection = NUM_RESOURCES - 1;
            } else if (currentSelection != 0 && offers[currentSelection - 1] != NULL)
                currentSelection--;
            break;
    }
}

std::string TradeMenu::getResourceString(int resource) {
    switch (resource) {
        case 0:
            return "wood";
        case 1:
            return "sheep";
        case 2:
            return "wheat";
        case 3:
            return "brick";
        case 4:
            return "rock";
    }
    return "";
}

void TradeMenu::createOffer(Player* player) {
    try {
        bool give = false;
        bool take = false;
        int portTrade = 0;
        if (glutGetModifiers() & GLUT_ACTIVE_SHIFT) {
            portTrade = -10;
        }
        for (int i = 0; i < NUM_RESOURCES; i++) {
            if (potentialOffer[i] < 0) {
                give = true;
                if (portTrade != -10 && potentialOffer[i] % getTradeRatio(player, i) == 0) { // trade to bank
                    portTrade += -potentialOffer[i] / getTradeRatio(player, i);
                } else {
                    portTrade = -10;
                }
            }
            if (potentialOffer[i] > 0) {
                take = true;
                portTrade -= potentialOffer[i];
            }
        }

        if (!give || !take) {
            throw "you cant trade for nothing!";
        }

        offers[currentOffer] = new TradeOffer(potentialOffer, player);
        if (portTrade == 0) {
            offers[currentOffer]->accept(NULL);
            delete offers[currentOffer];
            offers[currentOffer] = NULL;
        } else {
            currentOffer = (currentOffer + 1) % MAX_OFFERS;
        }
    } catch (const char* str) {
        std::cout << str << std::endl; // TODO: create popup to inform user that they dont have enough resources OR create check on increment instead
    }

    memset(potentialOffer, 0, sizeof (potentialOffer));
}

int TradeMenu::getTradeRatio(Player* player, int resource) {
    if (player->hasPort(resource))
        return 2;
    if (player->hasPort(-1))
        return 3;
    return 4;
}

void TradeMenu::acceptOffer(Player* player) {
    try {
        if (offers[currentSelection] == NULL) {
            throw "no such offer!";
        }
        offers[currentSelection]->accept(player);
        delete offers[currentSelection];
        offers[currentSelection] = NULL;
    } catch (const char* str) {
        std::cout << str << std::endl;
    }
    organizeTradeArray();
    currentSelection = 0;
}

void TradeMenu::organizeTradeArray() { // shuffle array towards front
    for (int i = MAX_OFFERS - 1; i > 0; i--) {
        if (i < MAX_OFFERS && offers[i] != NULL && offers[i - 1] == NULL) {
            offers[i - 1] = offers[i];
            offers[i] = NULL;
            i += 2;
        }
    }
}

void TradeMenu::Draw() {
    Menu::Draw();

    if (state == CREATE) {
        //        glPushMatrix();
        //        glTranslatef(currentSelection - 2.2, 0.1, -1.2);
        //        selector->Draw();
        //        glPopMatrix();

        //glColor3f(0, 0, 1);
        glPushMatrix();
        glTranslatef(-2.0, 0, -1);
        glScalef(0.007, 0.007, 1);
        glRasterPos2i(0, 0);
        glLineWidth(4);
        for (int i = 0; i < NUM_RESOURCES; i++) {
            glTranslatef(0, 1, 0);
            Vector3f textColor = getTextColor(potentialOffer[i] >= 0, i == currentSelection, false);
            glColor3f(textColor.r, textColor.g, textColor.b);

            std::string resource;
            std::stringstream ss;
            ss << abs(potentialOffer[i]);
            resource = ss.str();
            //            glRasterPos2f(1.2 * i - 2.1, 0);
            glutStrokeString(GLUT_STROKE_MONO_ROMAN, (const unsigned char*) resource.c_str());
        }
        glTranslatef(0, 0, 0);
        for (int i = 0; i < NUM_RESOURCES; i++) { // TODO: FIX RESOURCE ICONS
            resourceIcons[i]->Draw();
        }
        glPopMatrix();
    } else { // VIEW_OFFER
        glColor3f(0, 0, 1);
        int * offerResources;

        if (offers[currentSelection] == NULL) { // dont show empty offers
            return;
        }

        glPushMatrix();
        glTranslatef(-2.0, 0, -1);
        glScalef(0.007, 0.007, 1);
        glLineWidth(4);
        glRasterPos2i(0, 0);

        offerResources = offers[currentSelection]->getResources();
        for (int j = 0; j < NUM_RESOURCES; j++) {

            Vector3f textColor = getTextColor(offerResources[j] <= 0, false, !offers[currentSelection]->acceptable(currentPlayer));
            glColor3f(textColor.r, textColor.g, textColor.b);

            std::string resource;
            std::stringstream ss;
            ss << abs(offerResources[j]);
            resource = ss.str();
            //glRasterPos2f(1 * j, i);

            glutStrokeString(GLUT_STROKE_MONO_ROMAN, (const unsigned char*) resource.c_str());
        }

        glPopMatrix();
    }
}

Vector3f TradeMenu::getTextColor(bool positiveValue, bool selected, bool disabled) {
    if (positiveValue) {
        if (selected) {
            if (disabled) {
                return Vector3f(0.5, 0.5, 1.0); //111
            } else {
                return Vector3f(0.0f, 0.0f, 0.2f); //110
            }
        } else if (disabled) {
            return Vector3f(0.7, 0.7, 0.7); //101
        } else {
            return Vector3f(0.0f, 0.0f, 1.0f); //100
        }
    } else if (selected) {
        if (disabled) {
            return Vector3f(0.5f, 0.2f, 0.2f); //011
        } else {
            return Vector3f(0.4f, 0.0f, 0.0f); //010
        }
    } else if (disabled) {
        return Vector3f(1.0f, 0.7f, 0.7f); //001
    }
    return Vector3f(1.0f, 0.0f, 0.0f); //000
}

void TradeMenu::keyDown(unsigned char key, int x, int y, Player* currentPlayer) {
    this->currentPlayer = currentPlayer;
    switch (key) {
        case ESCAPE:
            break;

        case ENTER:
            state == VIEW_OFFERS ? acceptOffer(currentPlayer) : createOffer(currentPlayer);

            break;
        case TAB:
            currentSelection = 0;
            state == VIEW_OFFERS ? state = CREATE : state = VIEW_OFFERS;
            title = (state == VIEW_OFFERS ? "Trade - View Offers" : "Trade - Create Offer");
            break;
    }
}

