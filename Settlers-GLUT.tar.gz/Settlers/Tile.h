/* 
 * File:   Tile.h
 * Author: brandon
 *
 * Created on May 2, 2011, 8:00 PM
 */

#ifndef TILE_H
#define	TILE_H
#include "GamePiece.h"

#define ASCII_CONST 48
#define PI M_PI


#define WATER -2
#define DESERT -1
#define WOOD 0
#define SHEEP 1
#define WHEAT 2
#define BRICK 3
#define ROCK 4

static const Vector3f WATER_COLOR = Vector3f(0, 0.2, 0.8);
static const Vector3f DESERT_COLOR = Vector3f(0.95, 0.95, 0.7);
static const Vector3f WOOD_COLOR = Vector3f(0.1, 0.3, 0.1);
static const Vector3f SHEEP_COLOR = Vector3f(0.2, 0.6, 0.3);
static const Vector3f WHEAT_COLOR = Vector3f(0.6, 0.6, 0.1);
static const Vector3f BRICK_COLOR = Vector3f(0.6, 0.2, 0.1);
static const Vector3f ROCK_COLOR = Vector3f(0.4, 0.4, 0.4);
Vector3f getColorFor(int resource);
int getResourceForColor (Vector3f color);

class Road;

class Tile : public GamePiece {
public:
    class CornerNode;
    Tile(Vector3f position, int chit, int resource);
    Tile(const Tile& orig);
    virtual ~Tile();
    int getToken();
    Vector3f getPosition();
    int getResource();
    bool isBlocked();
    bool hasPort();
    bool bordersPort();
    bool nextToPort();
    void addPort(int type, int direction);

    void setBorderingTile(Tile* tile, Vector3f moveDirection);
    Tile* getBorderingTile(int direction);
    CornerNode* getCorner(int corner);
    void assignUnusedNodes();
    CornerNode* occupyCorner(int corner);
    void updateConnected();

    void Draw();
    void drawNumber();

    void glGenerateDisplayList();

    class CornerNode {
    public:
        CornerNode(Tile* creator);
        ~CornerNode();
        void setOccupied();
        bool isOccupied();
        Vector3f getPosition();
        CornerNode* getSelection(int direction);
        Vector2f getVectorDirection(int direction);
        void setConnectedNode(CornerNode* node, int position);
        void setBorderringTile(Tile* tile);
        void registerRoad(Road* road, int direction);
        void setIsLeft(bool left);
        bool isLeft();
        bool cornerIsOn(int roll);
        int getTileToken(int tile);
        int getResource(int tile);

        bool isOnWater();
        bool isBridge(Tile::CornerNode* node);
        int getPort();

        Road* getRoad(int num);

    private:
        void setPosition(Vector3f position);
        Vector3f position;
        bool occupied;
        bool water;

        int port;

        Road** roads; //array to say who owns which road where. index 0 = bottom, 1 = middle, 2 = top
        bool left;
        //connected represents the other connected nodes to the current
        CornerNode** connected; //bottom, middle, top
        //tiles represents the tiles bordering the current node
        Tile** tiles; // going from bottom left CCW
        friend class Tile;
    };

private:
    CornerNode** corners; // represent the corners of a hexagon starting bottom-left, going CCW
    Tile** tiles;
    bool port;

    bool setBlocked(bool blocked);
    void updateConnected(int i);

    int token; //number to roll
    int resource;
    bool blocked;

    friend class Robber;
};

#endif	/* TILE_H */

