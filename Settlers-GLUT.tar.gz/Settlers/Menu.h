/* 
 * File:   Menu.h
 * Author: brandon
 *
 * Created on May 19, 2011, 9:32 AM
 */

#ifndef MENU_H
#define	MENU_H
#include "Sprite.h"
#include <string>
#include <GL/freeglut.h>

#define ESCAPE 27
#define SPACE 32
#define ENTER 13
#define TAB 9

class Player;
 
class Menu {
public:
    Menu();
    Menu(std::string title);
    Menu(const Menu& orig);
    virtual ~Menu();
    
    //virtual void select(int direction);
    virtual void keyDown(unsigned char key, int x, int y, Player* player);
    
    void Draw();
    void Update(int t);
protected:
    std::string title;
    Sprite* menuSprite;
};

#endif	/* MENU_H */

