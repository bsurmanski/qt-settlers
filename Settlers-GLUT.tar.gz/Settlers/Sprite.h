/* 
 * File:   Sprite.h
 * Author: brandon
 *
 * Created on May 7, 2011, 1:07 PM
 */

#ifndef SPRITE_H
#define	SPRITE_H
#include "vmath.h"
#include <GL/gl.h>
#include <png.h>
#include <string>
#include <cstdlib>
#include <cassert>

#define PNG_SIG_BYTES 8
#define HEADER_LENGTH 8
#define EASE_CONST 10

class Sprite {
public:
    Sprite();
    Sprite(std::string filename);
    Sprite(const Sprite& orig);
    virtual ~Sprite();
    GLuint loadTexture(std::string filename);

    void Draw();
    void Update(int t);

    void setSize (Vector2f dimension);
    void setPosition(Vector3f position);

    void setTint(Vector3f tint);

    void easeTo(Vector3f location);
    void addState(std::string fileName);
    void changeState(int state);


private:
    int size;
    int state;
    Vector2f corner1;
    Vector2f corner2;
    char* load_png(std::string fileName, int* width, int* height);
    
    GLuint* texture;
    Vector3f color;

    Vector3f position;
    bool easing;
    Vector3f target;
};

#endif	/* SPRITE_H */

