/* 
 * File:   Player.cpp
 * Author: brandon
 * 
 * Created on May 3, 2011, 10:00 PM
 */

#include <iostream>
#include <sstream>
#include "Player.h"
#include "Board.h"

//maximum allowed pieces
#define NUMROADS 15
#define SETTLEMENTS 5
#define CITIES 4

//Player States
#define NORMAL 0
#define PLACING_ROAD 1
#define TRADE 2

Player::Player(Vector3f color) {
    this->color = color;
    currentBoard = NULL;
    selection = NULL;
    selector = new Sprite("selector.png");
    selector->addState("roadPlace.png");

    roads = new Road*[NUMROADS];
    for (int i = 0; i < NUMROADS; i++) {
        roads[i] = NULL;
    }

    settlements = new Settlement*[SETTLEMENTS + CITIES]; //holds all settlements and cities
    for (int i = 0; i < SETTLEMENTS + CITIES; i++) {
        settlements[i] = NULL;
    }

    resources = new int [NUM_RESOURCES];

    reset();

    startOfGame = true;
    rolled = false;
    currentPlayer = false;
}

Player::Player(const Player& orig) {
}

Player::~Player() {
    for (int i = 0; i < SETTLEMENTS + CITIES; i++) {
        if (settlements[i] != NULL)
            delete settlements[i];
    }
    for (int i = 0; i < NUMROADS; i++) {
        if (roads[i] != NULL)
            delete roads[i];
    }
    delete [] settlements;
    delete [] roads;
    delete selector;
}

void Player::setBoard(Board* board) {
    currentBoard = board;
    selection = currentBoard->getDefaultNodeSelection();
    selector->easeTo(selection->getPosition());
    reset();
}

void Player::reset() {
    for (int i = 0; i < SETTLEMENTS + CITIES; i++) { // reset settlements
        if (settlements[i] != NULL) {
            delete settlements[i];
            settlements[i] = NULL;
        }
    }

    placedSettlements = 0;
    placedCities = 0;

    for (int i = 0; i < NUMROADS; i++) { //reset roads
        if (roads[i] != NULL) {
            delete roads[i];
            roads[i] = NULL;
        }
    }
    placedRoads = 0;
    longestRoad = 0;

    for (int i = 0; i < NUM_RESOURCES; i++) { // zero out resources
        resources[i] = 0;
    }

    for (int i = 0; i < NUM_RESOURCES; i++) {
        resourcePorts[i] = false;
    }
    standardPort = false;

    points = 0;
    state = NORMAL;
}

//void Player::placeSettlement(int tile, int corner) { // NOT USED
//    try {
//        if (!startOfGame) {
//            for (int i = 0; i < 4; i++) {
//                if (resources[i] == 0) {
//                    throw "not enough resources";
//                }
//            }
//        }
//
//        Tile::CornerNode* cornerToPlace = currentBoard->occupyCorner(tile, corner);
//        settlements[placedSettlements] = new Settlement(cornerToPlace, color);
//        placedSettlements++;
//
//        if (STARTING_RESOURCES && startOfGame && placedSettlements == 1) {
//            for (int i = 0; i < 3; i++) {
//                //resources[settlements[i]->]
//            }
//        } else if (!startOfGame) {
//            for (int i = 0; i < 4; i++) {
//                resources[i]--;
//            }
//        }
//    } catch (const char* str) {
//        std::cout << str << std::endl; // COULD NOT PLACE PIECE
//    }
//}

void Player::placeSettlement() {
    if (placedSettlements < SETTLEMENTS && currentPlayer) {
        try {
            if (!startOfGame) {
                for (int i = 0; i < 4; i++) {
                    if (resources[i] == 0) {
                        throw "not enough resources";
                    }
                }
            } else {
                if (placedSettlements != placedRoads) {
                    throw "wait your turn. Placing too many settlements at a time at start of game";
                }
            }

            if (isOnNetwork(selection) || startOfGame) {
                Tile::CornerNode* placement = currentBoard->occupyCorner(selection);
                settlements[placedSettlements + placedCities] = new Settlement(placement, color);
                placedSettlements++;

                if (selection->getPort() != WATER) { //add ports if exist on corner
                    if (selection->getPort() == DESERT) {
                        standardPort = true;
                    } else {
                        resourcePorts[selection->getPort()] = true;
                    }
                }
                if (startOfGame) {
                    if (STARTING_RESOURCES && placedSettlements == 1) {
                        for (int i = 0; i < 3; i++) { // give starting resources for first settlement
                            resources[selection->getResource(i)]++;
                        }
                    }
                } else {
                    for (int i = 0; i < 4; i++) {
                        resources[i]--;
                    }
                }
            }
        } catch (const char* str) {
            std::cout << str << std::endl; // COULD NOT PLACE PIECE
        }
    }
}

/**
 * used for initialization of placing roads
 */
void Player::placeRoad() {
    if (state == NORMAL && placedRoads < NUMROADS) {
        state = PLACING_ROAD;
    } else {
        state = NORMAL;
    }
    selector->changeState(state);
}

/**
 * used once already 'placingRoad', called once a direction is chosen
 * @param direction direction to place road
 */
void Player::placeRoad(int direction) {
    if (placedRoads < NUMROADS && resources[WOOD] >= 1 && resources[BRICK] >= 1 || (startOfGame && placedRoads < placedSettlements)) {
        int roadIndex = direction;
        if (roadIndex == 3)
            roadIndex = 1; // direction is cardinal, yet nodes only have 3 directions; left/right are treated as one

        if (!isOnNetwork(selection)) {
            state = NORMAL;
            selector->changeState(state);
            return; // not valid road placement
        } else if (selection->isOccupied()) {
            for (int i = 0; i < placedSettlements + placedCities; i++) {
                if (settlements[i]->getCorner() == selection) {
                    break;
                } else if (i == (placedSettlements + placedCities) - 1) {
                    return; // cant build road through other player's city
                }
            }
        }

        if (selection->getRoad(roadIndex) == NULL) { // no road already in place
            try {
                if (selection->isBridge(selection->getSelection(direction))) {
                    if (!BRIDGES || !startOfGame && resources[ROCK] < 1) { // cannot make bridge, not allowed, or not enough rock
                        throw "attempt to make bridge";
                    }
                    if (!startOfGame) {
                        resources[ROCK] -= 1;
                    }
                } else if (selection->getSelection(direction)->isOnWater()) {
                    if (!BOATS || !startOfGame && (resources[SHEEP] < 1 || resources[WOOD] < 1)) {
                        throw "attempt to make boat";
                    }
                    if (!startOfGame) {
                        resources[SHEEP]--;
                        resources[WOOD]--;
                    }
                }
                roads[placedRoads] = new Road(selection, selection->getSelection(direction), color);
                placedRoads++;
                if (!startOfGame) {
                    resources[WOOD]--;
                    resources[BRICK]--;
                } else {
                    currentPlayer = false; //start of game, only allowed to place one road/ settlement at a time
                    if (placedRoads == 2) {
                        startOfGame = false;
                        rolled = true;
                    }
                }
            } catch (const char* err) {
                std::cout << err << std::endl;
                return; // cant place road, for whatever reason
            }
            state = NORMAL;
            selector->changeState(state);
        }
    }
}

Vector3f Player::getColor() {
    return color;
}

bool Player::hasPort(int type) {
    if (type >= 0 && type <= NUM_RESOURCES) {
        return resourcePorts[type];
    }
    return standardPort;
}

bool Player::endTurn() {
    if (state == NORMAL && rolled || (startOfGame && placedRoads == placedSettlements && placedRoads == 1)) {
        rolled = false;
        currentPlayer = false;
        return true;
    }
    return false;
}

void Player::beginTurn() {
    currentPlayer = true;
}

/**
 * 
 * @param node
 * @return
 */
bool Player::isOnNetwork(Tile::CornerNode* node) {
    for (int i = 0; i < 3; i++) { // check for connecting roads
        if (selection->getRoad(i) != NULL && selection->getRoad(i)->getPlayerColor() == color) {
            return true;
        }
    }
    if (selection->isOccupied()) {
        for (int i = 0; i < placedSettlements + placedCities; i++) { // check to see if it is current player's settlement
            if (settlements[i]->getCorner() == node)
                return true;
        }
    }
    return false;
}

bool Player::isPlacingRoad() {
    return state == PLACING_ROAD;
}

void Player::upgradeSettlement() {
    if (resources[WHEAT] >= 2 && resources [ROCK] >= 3) {
        for (int i = 0; i < placedSettlements + placedCities; i++) {
            if (settlements[i]->position == selection->getPosition()) {
                if (!settlements[i]->isCity()) { //only upgrade if not city
                    settlements[i]->upgradeToCity();
                    placedSettlements--;
                    placedCities++;
                    resources[WHEAT] -= 2;
                    resources[ROCK] -= 3;
                    break;
                } else {
                    return;
                }
            }
        }
    }
}

std::string Player::getResourceString() {
    std::string str = "";
    for (int i = 0; i < NUM_RESOURCES; i++) {
        str += IntToStr(resources[i]) + " ";
    }
    return str;
}

int Player::getResource(int resource) {
    return resources[resource];
}

std::string Player::IntToStr(int n) {
    std::ostringstream result;
    result << n;
    return result.str();
}

void Player::Update(int t) {
    selector->Update(t);
}

void Player::Draw() {
    for (int i = 0; i < placedSettlements + placedCities; i++) {
        settlements[i]->Draw();
    }
    for (int i = 0; i < placedRoads; i++) {
        roads[i]->Draw();
    }
    if (currentPlayer)
        selector->Draw();
}

bool Player::isNormalState() {
    return state == NORMAL;
}

void Player::select(int direction) {
    if (state == NORMAL && currentPlayer) {
        if (selection->getSelection(direction) != NULL)
            selection = selection->getSelection(direction);
        selector->easeTo(selection->getPosition() + Vector3f(0, 0, 2));
    } else if (state == PLACING_ROAD) { //placing road
        placeRoad(direction);
    }
}

Vector2f Player::rollDice() {
    if (state == NORMAL && !rolled && !startOfGame) {
        rolled = true;
        return currentBoard->rollDice();
    }
}

void Player::CollectResourcesOn(int num) {
    Vector2i collection;

    for (int i = 0; i < placedSettlements + placedCities; i++) {
        if (settlements[i]->tileIsOn(num)) {
            for (int j = 0; j < 3; j++) {
                collection = settlements[i]->collectionFromTile(num, j);
                resources[collection.s] += collection.t;
            }
        }
    }
}

void Player::tradeResource(int resource) {
    if (state == TRADE) {
        this->resources[resource]++;
        state = NORMAL;
    } else if (resource >= 4) {
        resource -= 4;
        state = TRADE;
    }
}

