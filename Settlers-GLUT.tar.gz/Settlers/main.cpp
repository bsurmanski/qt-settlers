/* 
 * File:   main.cpp
 * Author: brandon
 *
 * Created on February 16, 2011, 6:11 PM (from animation test?)
 *
 *
 * Note to self, next time create a registry list for drawing, so one call to register(gameComponent) will add it to the stack, 
 * and a call to main::Draw() will draw all the registered, or main::Update() will update game logic.
 * Have different lists for different global game states?
 * 
 * Quick TODO: networking, menus, trading
 * 
 * TODO: create networking constructs. One player will be the server, others clients. server will control passing of information
 * clients will send an update to server everytime anything changes (put in Update?) server will then broadcast new things to other clients
 */

#include <cstdlib>
#include <sstream>
#include <string>
#include <GL/freeglut.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <ctime>
#include <vector>
#include "vmath.h"
#include "Board.h"
#include "Player.h"
#include "Sprite.h"
#include "Menu.h"
#include "TradeMenu.h"

// Game states
#define MENU 0
#define INGAME 1
#define TRADE 2
#define PAUSE 3

using namespace std;

// declare methods
void resize(int width, int height);
void Draw();
void Update(int t);
void keyDown(unsigned char key, int x, int y);
void specialKeyDown(int key, int x, int y);
void specialKeyUp(int key, int x, int y);
void InitGL(int Width, int Height);

void initResources();
void newMenu();
void newGame();

void drawPlayerPorts();
void drawGUI();
void cleanUp();

bool fullscreen; // if fullscreen or not
int window; // reference int to the window representation used by glut

int state;

Vector3f globalRotation;
Vector3f globalPosition;
Board* board;
Player** players;

TradeMenu* tradeMenu;

#define MAX_PLAYERS 8
int localPlayers;
int networkPlayers;
int currentPlayer;

#define NUMBER_OF_PLAYERS (localPlayers+networkPlayers)

Vector2f dice;

Sprite* resourcePane;
Sprite* portIcons;

static const Vector3f possiblePlayerColors[] = {
    Vector3f(1, 0, 0),
    Vector3f(0, 0, 0.6),
    Vector3f(0.6, 0.6, 0.2),
    Vector3f(1, 1, 1),
    Vector3f(0, 1, 0),
    Vector3f(0.5, 0.2, 0.2),
    Vector3f(0.4, 0.4, 0.4),
    Vector3f(0.6, 0.1, 0.6)
};

//GLuint listsIndex = glGenLists(10);  // create 10 display lists

/*
 * 
 */
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_ALPHA | GLUT_DEPTH);
    glutInitWindowSize(640, 480); // default window size set
    glutInitWindowPosition(0, 0);
    fullscreen = false;
    window = glutCreateWindow("Settlers!");
    glutReshapeFunc(&resize);
    glutTimerFunc(0, &Update, 0);
    glutDisplayFunc(&Draw);
    InitGL(640, 480);
    glutKeyboardFunc(&keyDown);
    glutSpecialFunc(&specialKeyDown);
    glutSpecialUpFunc(&specialKeyUp);

    initResources();
    newGame();

    glutMainLoop(); // start main loop

    //cleanUp();
    return 0;
}

void initResources() {
    globalRotation = Vector3f(-40, 0, 0);
    globalPosition = Vector3f(0, 0, -30);

    localPlayers = 3;
    networkPlayers = 0;
}

void newMenu() {

}

void newGame() {
    srand(time(NULL));

    state = INGAME;

    board = new Board();
    players = new Player*[localPlayers];
    for (int i = 0; i < localPlayers; i++) { //initialize Players
        players[i] = new Player(possiblePlayerColors[i]);
        players[i]->setBoard(board);
    }

    dice = Vector2f();

    currentPlayer = rand() % NUMBER_OF_PLAYERS;

    players[currentPlayer]->beginTurn();

    resourcePane = new Sprite("resourcePane.png");
    resourcePane->setSize(Vector2f(0.75, 0.25));
    resourcePane->setTint(players[currentPlayer]->getColor());

    portIcons = new Sprite("anchor.png");
    portIcons->setSize(Vector2f(0.05, 0.05));

    tradeMenu = new TradeMenu();
}

void cleanUp() {
    delete resourcePane;
    delete board;
    for (int i = 0; i < localPlayers; i++) {
        delete players[i];
    }
    delete [] players;
}

/*
 * Messy OpenGL initilization
 */
void InitGL(int Width, int Height) //call this right after our OpenGL window is created.
{
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f); // This Will Clear The Background Color To Black
    glClearDepth(1.0); // Enables Clearing Of The Depth Buffer
    glDepthFunc(GL_LESS); // The Type Of Depth Test To Do
    glEnable(GL_DEPTH_TEST); // Enables Depth Testing
    glShadeModel(GL_SMOOTH); // Enables Smooth Color Shading

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    glEnable(GL_NORMALIZE);
    glEnable(GL_COLOR_MATERIAL);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity(); // Reset The Projection Matrix
    gluPerspective(45.0f, (GLfloat) Width / (GLfloat) Height, 0.1f, 100.0f); // Calculate The Aspect Ratio Of The Window
    glMatrixMode(GL_MODELVIEW);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    // glutSetKeyRepeat(GLUT_KEY_REPEAT_OFF); // no key repeats if key held
}

/** FIXME: resizing will often permanently break the games drawing until driver restarted.
 * Resize the view and window
 * @param width
 * @param height
 */
void resize(int width, int height) {
    if (height == 0) // Prevent A Divide By Zero If The Window Is Too Small
        height = 1;

    glViewport(0, 0, width, height); // Reset The Current Viewport And Perspective Transformation
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0f, (GLfloat) width / (GLfloat) height, 0.1f, 100.0f);
    glMatrixMode(GL_MODELVIEW);
    glutPostRedisplay();
}

void Draw() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Clear The Screen And The Depth Buffer
    //glMatrixMode(GL_MODELVIEW);
    glLoadIdentity(); // Reset The View

    switch (state) {
        case MENU:
            drawGUI();
            break;

        case INGAME:
            glPushMatrix(); // add a view matrix to the stack
            glTranslatef(globalPosition.x, globalPosition.y, globalPosition.z); // move the camera 20 units backwards
            glRotatef(globalRotation.x, 1, 0, 0);
            glRotatef(globalRotation.y, 0, 1, 0);
            glRotatef(globalRotation.z, 0, 0, 1);
            board->Draw();
            for (int i = 0; i < NUMBER_OF_PLAYERS; i++)
                players[i]->Draw();
            glPopMatrix(); // remove a view matrix from the stack
            drawGUI();
            break;

        case TRADE:
            drawGUI();
            break;
    }
    glutSwapBuffers(); // switch out for the second buffer (things are drawn on an offscreen representation and swapped on to avoid screwy stuff)
}

void drawGUI() {
    std::stringstream ss;
    std::string buf;
    switch (state) {
        case MENU:

            break;

        case TRADE:
            glPushMatrix();
            glTranslatef(0, 0, -5);
            tradeMenu->Draw();
            glPopMatrix();
            //break;

        case INGAME:
            glPushMatrix();
            glTranslatef(0.8, -0.6, -2.4);
            resourcePane->Draw();
            glPopMatrix();

            glPushMatrix();
            glTranslatef(0.375, -0.65, -2);
            drawPlayerPorts();
            glPopMatrix();

            glPushMatrix();
            glTranslatef(0.475, -0.55, -2);
            glScalef(0.0005, 0.0005, 1);
            glLineWidth(1);
            glColor3f(1, 1, 1);
            //glRasterPos2i(0, 5);
            int resource;
            for (int i = 0; i < 5; i++) {
                glTranslatef(0.5, 0, 0);
                ss.str("  ");
                resource = players[currentPlayer]->getResource(i);
                ss << resource;
                buf = ss.str();
                glRasterPos2f(0.1 * i + 0.3, 0);
                glutStrokeString(GLUT_STROKE_MONO_ROMAN, (const unsigned char*) buf.c_str());
            }
            glRasterPos2f(0.6, 0.1);
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, dice.s + 48);
            glRasterPos2f(0.7, 0.1);
            glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, dice.t + 48);
            glPopMatrix();
            break;
    }
}

void drawPlayerPorts() { // draw owned ports of the player
    for (int i = 0; i < 6; i++) {
        glTranslatef(0.1, 0, 0);
        if (players[currentPlayer]->hasPort(i)) {
            portIcons->setTint(getColorFor(i));
        } else {
            portIcons->setTint(Vector3f(0.05, 0.05, 0.05));
        }
        portIcons->Draw();
    }
}

void Update(int t) {
    switch (state) {
        case MENU:

            break;
        case INGAME:
            board->Update(t);
            for (int i = 0; i < NUMBER_OF_PLAYERS; i++) {
                players[i]->Update(t);
            }
            break;
    }
    //glutPostRedisplay(); // redraw
    glutTimerFunc(18, &Update, t); // reupdate
}

void keyDown(unsigned char key, int x, int y) {
    /* avoid thrashing this procedure */
    usleep(100);
    if (state == TRADE) {
        tradeMenu->keyDown(key, x, y, players[currentPlayer]);
        glutPostRedisplay();
        if (key != ESCAPE)
            return;
    }
    switch (key) {
        case ESCAPE:
            state == INGAME ? state = PAUSE : state = INGAME;
            //glutDestroyWindow(window); /* shut down our window */
            //exit(0); /* exit the program...normal termination. */
            break;

        case ENTER:
            if (state == INGAME && players[currentPlayer]->endTurn()) {
                currentPlayer = (currentPlayer + 1) % NUMBER_OF_PLAYERS;
                players[currentPlayer]->beginTurn();
                resourcePane->setTint(players[currentPlayer]->getColor());
            } else if (state == TRADE) {
                tradeMenu->createOffer(players[currentPlayer]);
            }
            break;

        case SPACE:
            delete board;
            board = new Board();
            for (int i = 0; i < NUMBER_OF_PLAYERS; i++) {
                players[i]->setBoard(board);
            }
            break;

        case '8': // up
            globalPosition.y += 1;
            break;
        case '2': // down
            globalPosition.y -= 1;
            break;
        case '4': // left
            globalPosition.x -= 1;
            break;
        case '6': // right
            globalPosition.x += 1;
            break;
        case '7': // rotate left
            globalRotation.z += 5;
            break;
        case '9': // rotate right
            globalRotation.z -= 5;
            break;
        case '1': // spin up
            if (globalRotation.x < 0)
                globalRotation.x += 5;
            break;
        case '3': // spin down
            if (globalRotation.x > -90)
                globalRotation.x -= 5;
            break;
        case '5': // reset view
            globalRotation = Vector3f(-40, 0, 0);
            globalPosition = Vector3f(0, 0, -30);
            break;
        case '+': // zoom view in
            if (globalPosition.z < -5)
                globalPosition.z++;
            break;
        case '-': // zoom view out
            if (globalPosition.z > -70)
                globalPosition.z--;
            break;
        case 'r':
            dice = players[currentPlayer]->rollDice();
            if (dice.s + dice.t == 7) {
                while (!board->moveRobber(rand() % board->getNumberOfTiles()));
                // MOVE ROBBER//  state = players[currentPlayer]->s;
            } else {
                for (int i = 0; i < NUMBER_OF_PLAYERS; i++) {
                    players[i]->CollectResourcesOn(dice.s + dice.t);
                }
            }
            break;
        case 'x': // upgrade
            players[currentPlayer]->upgradeSettlement();
            break;
        case 'z': // place settlement
            players[currentPlayer]->placeSettlement();
            break;
        case 'a': // place road
            players[currentPlayer]->placeRoad();
            break;
        case 't': // trade
            state = TRADE;
            break;
    }
    glutPostRedisplay();
}

void specialKeyDown(int key, int x, int y) {
    int selectionDir = 0;
    switch (key) {
        case GLUT_KEY_UP:
            selectionDir = 2;
            break;
        case GLUT_KEY_DOWN:
            selectionDir = 0;
            break;
        case GLUT_KEY_LEFT:
            selectionDir = 3;
            break;
        case GLUT_KEY_RIGHT:
            selectionDir = 1;
            break;
    }
    switch (state) {
        case INGAME:
            players[currentPlayer]->select(selectionDir);
            break;
        case TRADE:
            tradeMenu->select(selectionDir, players[currentPlayer]);
            break;
    }
    glutPostRedisplay();
}

/*
 Key released function
 */
void keyUp(unsigned char key, int x, int y) {

}

void specialKeyUp(int key, int x, int y) {
    switch (key) {
        case GLUT_KEY_UP:
        case GLUT_KEY_DOWN:
            //sheep->stop(Vector3f(0,1,0));
            break;
        case GLUT_KEY_LEFT:
        case GLUT_KEY_RIGHT:
            //sheep->stopRotation(Vector3f(0,0,1));
            break;
    }
}
