/* 
 * File:   TradeMenu.h
 * Author: brandon
 *
 * Created on May 19, 2011, 9:15 PM
 */

#ifndef TRADEMENU_H
#define	TRADEMENU_H
#include <GL/freeglut.h>
#include "Menu.h"
#include "Player.h"
#include "TradeOffer.h"
#include "Button.h"

#define MAX_OFFERS 3

#define VIEW_OFFERS 0
#define CREATE 1

//class Player;

class TradeMenu : public Menu{
public:
    TradeMenu(std::string title);
    TradeMenu();
    TradeMenu(const TradeMenu& orig);
    virtual ~TradeMenu();
    
    void select(int direction, Player* currentPlayer);
    void createOffer(Player* player);
    void acceptOffer(Player* player);
    
    void keyDown(unsigned char key, int x, int y, Player* currentPlayer);
    
    void Draw();
private:
    std::string getResourceString(int resource);
    int getTradeRatio(Player* player, int resource);
    Vector3f getTextColor(bool positiveValue, bool selected, bool disabled);
    void organizeTradeArray();
    int state;
    int potentialOffer[NUM_RESOURCES];
    TradeOffer** offers;
    Player* currentPlayer;
    Sprite* selector; 
    Sprite* resourceIcons[NUM_RESOURCES];
    int currentOffer;
    int currentSelection;
    

};

#endif	/* TRADEMENU_H */

