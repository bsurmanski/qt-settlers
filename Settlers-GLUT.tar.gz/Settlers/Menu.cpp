/* 
 * File:   Menu.cpp
 * Author: brandon
 * 
 * Created on May 19, 2011, 9:31 AM
 * TODO: create main menu, create pause menu, create option menu (for game-independant options), and pregame menu to set map options etc
 */

#include "Menu.h"

Menu::Menu(){}

Menu::Menu(std::string title) {
    this->title = title;
    menuSprite = new Sprite("menu.png");
    menuSprite->setSize(Vector2f(6.4, 4));
    menuSprite->setPosition(Vector3f(0, 0, -1));
}

Menu::Menu(const Menu& orig) {
}

Menu::~Menu() {
}

void Menu::keyDown(unsigned char key, int x, int y, Player* player){}

void Menu::Draw() {
    glPushMatrix();
    glTranslatef(0, 0, -2);
    menuSprite->Draw();
    glPopMatrix();
    glColor3f(0, 0, 1);
    glDisable(GL_LIGHTING);
    glRasterPos2f(-2, 1.1);
    glutBitmapString(GLUT_BITMAP_HELVETICA_18, (const unsigned char*) title.c_str());
    glEnable(GL_LIGHTING);
}

