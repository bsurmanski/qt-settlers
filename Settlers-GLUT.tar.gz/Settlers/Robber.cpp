/* 
 * File:   Robber.cpp
 * Author: brandon
 * 
 * Created on May 3, 2011, 10:03 PM
 */

#include "Robber.h"
#include <GL/glut.h>

Robber::Robber(Tile* tile) {
    position = tile->getPosition();
    target = position;
    tile->setBlocked(true);
    model = new Model("robber.mdl");
    model->changeColor(Vector3f(0.5, 0.5, 0.5));
    currentTile = tile;
}

Robber::Robber(const Robber& orig) {
}

Robber::~Robber() {
}

void Robber::moveTo(Tile* tile) {
    currentTile->setBlocked(false);
    currentTile = tile;
    target = tile->getPosition();
    tile->setBlocked(true);
}

void Robber::Update(int t) {
    if (position != target) {
        position += Vector3f((target.x - position.x), (target.y - position.y), pow((target.y - position.y),2)*1+target.z-position.z)/10; //((position + target) / 2 - position).x);
    }
    glutPostRedisplay();
}

void Robber::Draw() {
    glPushMatrix();
    glTranslatef(position.x, position.y, position.z);
    model->Draw();
    glPopMatrix();
}

