/* 
 * File:   Board.cpp
 * Author: brandon
 * 
 * Created on May 2, 2011, 8:03 PM
 */

#include "Board.h"
#include "Seaport.h"
#include <math.h>


/**
 * warning! complicated board init logic. sets up the hexagons, and connects the corner nodes
 */
Board::Board() {
    boardSize = 1;

    for (int i = 1; i < BOARDRADIUS; i++) {
        boardSize += i * 6;
    }

    numDeserts = (int) std::max(floor((double) (boardSize / 10)) - 4 * ISLANDS, 0.0);
    numWaterTiles = 0;

    innerBoardSize = boardSize; // board not including water

    if (WATER_BORDER) {
        boardSize += BOARDRADIUS * 6; // board with water
    }

    int* chits = getScrambledChits();
    int* resources = getScrambledResources(numDeserts);
    tiles = new Tile*[boardSize];

    for (int i = 0; i < boardSize; i++) { // null out initial tiles; no really necessary because they get overridden, but just incase
        tiles[i] = NULL;
    }

    robber = NULL;
    int count = 0;
    float connectionCount = 0; // used for connecting hexs to hexes from inner rings
    float angle = PI / 6;
    int previousFirstIndex;
    int currentFirstIndex = 0;
    int aboveTileIndex;
    Vector3f direction = Vector3f(TILE_SEPARATION * cos(angle), TILE_SEPARATION * sin(angle), 0); // direction to place next tile in
    Vector3f previousTile; // reference direction to previous tile in same ring
    Vector3f aboveTile; // refrerence direction to tile(s) in above-ring
    Vector3f position = Vector3f(); //position to create tile at

    for (int i = 0; i < BOARDRADIUS + WATER_BORDER; i++) { // radially generate the shape

        previousFirstIndex = currentFirstIndex;
        currentFirstIndex = count;
        if (i != 1) {
            connectionCount = 6 * (i - 1);
        } else {
            connectionCount = 1;
        }

        position = Vector3f(0, -i * TILE_SEPARATION, 0);
        angle = PI / 6;
        for (int j = 0; j < i * 6 || (i == 0 && j == 0); j++) { //repeat until ring is full, or if first hexagon
            tiles[count] = new Tile(position, chits[count], resources[count]); //create new tile at position, with CHIT and RESOURCE

            if (i != 0) { //set node relationships.

                if (fabs(connectionCount - round(connectionCount)) < EPSILON) {
                    connectionCount = round(connectionCount); // prevents error propagation
                }
                // connect to ring above
                aboveTile = Vector3f(TILE_SEPARATION * cos(angle + PI / 3), TILE_SEPARATION * sin(angle + PI / 3), 0);
                if (j == (i * 6) - 1) {
                    aboveTileIndex = previousFirstIndex;
                } else {
                    aboveTileIndex = count - ((int) floor(connectionCount));
                }
                
                try {
                tiles[count]->setBorderingTile(tiles[aboveTileIndex], aboveTile);
                } catch (Tile* t){
                    std::cout << " tile count=" << count << " t count=" << aboveTileIndex << std::endl;
                    throw;
                }

                if (connectionCount != floor(connectionCount)) { // tile not on corner, connect to 2 above rings
                    aboveTile = Vector3f(TILE_SEPARATION * cos(angle + PI * 2 / 3), TILE_SEPARATION * sin(angle + PI * 2 / 3), 0);
                    tiles[count]->setBorderingTile(tiles[count - ((int) ceil(connectionCount))], aboveTile);
                }

                connectionCount += (1.0 / i);

                if (j != 0) { // connect to previous tile
                    tiles[count]->setBorderingTile(tiles[count - 1], previousTile); //set previous tile
                }
                previousTile = -direction;
                if (j == ((i * 6) - 1)) { // if last tile in ring, link to first tile
                    tiles[count]->setBorderingTile(tiles[count - j], direction);
                }
            }

            if (resources[count] == DESERT) {
                if (!robber)
                    robber = new Robber(tiles[count]); // create robber on desert
            }

            position += direction;

            if (i != 0 && ((count % i) == 0)) { //rotate on corners
                angle += PI / 3;
                direction = Vector3f(TILE_SEPARATION * cos(angle), TILE_SEPARATION * sin(angle), 0);
            }
            tiles[count]->assignUnusedNodes(); // create new corner nodes if not initialized
            count++;
        }
    }

    placePorts();
    generateGLDisplayList(1); // NOTE: temporary (kinda) 1 thrown in there
    delete chits;
    delete resources;
}

Board::Board(const Board& orig) {
}

Board::~Board() {
    for (int i = 0; i < boardSize; i++) {
        delete tiles[i];
    }
    delete [] tiles;
    if (robber != NULL)
        delete robber;
}

void Board::scrambleIntArray(int* array, int size) {
    int swap;
    int randNum;
    for (int entropy = 0; entropy < 5; entropy++) { // repeat for added entropy
        for (int i = 0; i < size; i++) { // scramble the array
            randNum = rand() % size;
            swap = array[randNum];
            array[randNum] = array[i];
            array[i] = swap;
        }
    }
}

int* Board::getScrambledChits() {
    int* chits = new int[boardSize];
    int chitOrder [18] = {8, 6, 5, 9, 10, 4, 3, 11, 12, 2, 3, 11, 10, 4, 5, 9, 8, 6}; // standardized chit numbering
    for (int i = 0; i < innerBoardSize; i++) {
        chits[i] = chitOrder[i % 18]; // keeps distribution proper
    }
    scrambleIntArray(chits, innerBoardSize);
    return chits;
}

int* Board::getScrambledPorts(int ports){
    int* retPorts = new int [ports];
    int portOrder [10] = {-1, 0, -1, 1, -1, 2, -1, 3, -1, 4};
    for (int i = 0; i < ports; i++){
        retPorts[i] = portOrder[i % 10];
    }
    scrambleIntArray (retPorts, ports);
    return retPorts;
}

/*
 * gets the resource tiles for the game, scrambled.
 * size includes the number of deserts
 * 
 */
int* Board::getScrambledResources(int deserts) {
    assert(deserts <= boardSize);
    int resourceCount [] = {0, 0, 0, 0, 0};
    int* resources = new int [boardSize];
    for (int i = 0; i < boardSize; i++) {
        if (i < innerBoardSize) {
            if (ISLANDS) {
                if (i % 2 == 0) {
                    resources[i] = ((i % 10) / 2);
                    resourceCount[resources[i]]++;
                } else {
                    resources[i] = WATER;
                    numWaterTiles++;
                }
            } else {
                resources[i] = (i % NUM_RESOURCES); //loop around from 1 to 5
            }
        } else {
            resources[i] = WATER;
            numWaterTiles++;
        }
    }

    for (int i = 0; i < deserts; i++) {
        if (resources[innerBoardSize - 1 - i] >= 0 && resources[innerBoardSize - 1 - i] < NUM_RESOURCES)
            resourceCount[resources[innerBoardSize - 1 - i]]--;
        resources[innerBoardSize - 1 - i] = DESERT; // assign deserts
    }

    scrambleIntArray(resources, innerBoardSize);
    return resources;
}

int Board::indexOfMaxFromArray(int* array, int size) { // NOTE: UNUSED
    int max = array[0];
    int maxIndex = 0;
    for (int i = 0; i < size; i++) {
        if (array[i] > max) {
            maxIndex = i;
            max = array[i];
        }
    }
    return maxIndex;
}

void Board::calculateNumberOfPorts() {

}

void Board::placePorts() {
    numPorts = BOARDRADIUS * 3; //(int) numWaterTiles / 2;
    
    int* portNumbers = getScrambledPorts(numPorts);

    ports = new Seaport*[numPorts];

    for (int i = 0; i < numPorts; i++) { // null out ports
        ports[i] = NULL;
    }

    int waterTileIndices [numWaterTiles];

    for (int i = 0, currentIndex = 0; i < boardSize; i++) { // find all the water tiles
        if (tiles[i]->getResource() == WATER) {
            waterTileIndices[currentIndex] = i;
            currentIndex++;
        }
    }

    for (int i = 0, currentIndex = 0; i < numPorts && currentIndex < numWaterTiles; i++) {
        int possibilities = 0;
        int placementDirection;
        bool possible [] = {0, 0, 0, 0, 0, 0};

        if (tiles[waterTileIndices[currentIndex]]->bordersPort()) {
            currentIndex++;
            i--;
            continue; // dont put ports next to each other 
        }

        for (int j = 0; j < 6; j++) {
            if (tiles[waterTileIndices[currentIndex]]->getBorderingTile(j) != NULL
                    && (tiles[waterTileIndices[currentIndex]]->getBorderingTile(j)->getResource() != WATER)
                    && !tiles[waterTileIndices[currentIndex]]->getBorderingTile(j)->nextToPort()) {
                possibilities++;
                possible[j] = true;
            }
        }

        if (possibilities == 0) {
            currentIndex++;
            continue; // cant have unreachable port
        }

        placementDirection = 1 + (rand() % possibilities); // which of the possibilities is chosen

        for (int j = 0; j < 6; j++) { //essentially, this grabs a random side from the possible sides the port can be placed
            if (possible[j] == true) {
                placementDirection = j;
                break; // temp fix
            }
            if (placementDirection == 0 && possible[j] == true) {
                placementDirection = j;
                break;
            }
        }
            ports[i] = new Seaport(tiles[waterTileIndices[currentIndex]], placementDirection, getColorFor(portNumbers[i])); // half of the seaports should be 3-1s

        //placementDirection = (placementDirection + 3) % 6;
        tiles[waterTileIndices[currentIndex]]->addPort(ports[i]->getType(), placementDirection);
        currentIndex++;
    }
    delete portNumbers;
}

/**
 * gets the closest tile to the position; if the vector is very far away, this would be a map edge
 * @param position
 * @return pointer to closest tile
 */
Tile* Board::getClosestTile(Vector3f position) {
    float minimum = (position - tiles[0]->getPosition()).lengthSq();
    int minIndex = 0;
    for (int i = 0; i < boardSize; i++) {
        if ((position - tiles[0]->getPosition()).lengthSq() < minimum) {
            minIndex = i;
        }
    }
    return tiles[minIndex];
}

int Board::getNumberOfTiles() {
    return innerBoardSize;
}

/**
 * move the robber, return true if successful
 * @param tile
 * @return 
 */
bool Board::moveRobber(int tile) {
    if (numDeserts == 0) {
        return true;
    } else if (tiles[tile]->getResource() != WATER) {
        robber->moveTo(tiles[tile]);
        return true;
    }
    return false;
}

float Board::getBorderSize() {
    return (TILE_SEPARATION - 2 * sin(PI / 3));
}

Tile::CornerNode* Board::getDefaultNodeSelection() {
    return tiles[0]->getCorner(0);
}

Tile::CornerNode* Board::occupyCorner(int tile, int corner) {
    return tiles[tile]->occupyCorner(corner);
}

Tile::CornerNode* Board::occupyCorner(Tile::CornerNode* corner) {
    for (int i = 0; i < boardSize; i++) {
        for (int j = 0; j < 6; j++) {
            if (tiles[i]->getCorner(j) == corner) {
                return occupyCorner(i, j);
            }
        }
    }
    throw "corner not found";
}

Vector2f Board::rollDice() {
    return Vector2f(rand() % 6 + 1, rand() % 6 + 1);
}

void Board::Draw() {
    glCallList(displayListIndex);
    glColor3f(1, 1, 1);
    glCallList(numbersDisplayList);
    if (numDeserts > 0) {
        robber->Draw();
    }
}

/**
 * get display list for supah fast generation
 * @param index
 */
void Board::generateGLDisplayList(GLuint index) {
    displayListIndex = index;
    numbersDisplayList = index + 1;

    glNewList(displayListIndex, GL_COMPILE);
    glBegin(GL_TRIANGLES);
    for (int i = 0; i < boardSize; i++) {
        tiles[i]->glGenerateDisplayList();
    }

    for (int i = 0; i < numPorts; i++) {
        if (ports[i] != NULL)
            ports[i]->glGenerateDisplayList();
    }
    glEnd();
    glEndList();

    glNewList(numbersDisplayList, GL_COMPILE);
    glColor3f(0, 0, 0);
    for (int i = 0; i < boardSize; i++) {
        tiles[i]->drawNumber(); //fixed numbers lagging behind by using stoke string instead of bitmap
    }
    glEndList();
} 

void Board::Update(int t) {
    if (numDeserts != 0)
        robber->Update(t);
}