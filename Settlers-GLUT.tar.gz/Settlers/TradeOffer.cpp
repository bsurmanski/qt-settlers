/* 
 * File:   TradeOffer.cpp
 * Author: brandon
 * 
 * Created on May 18, 2011, 3:14 PM
 */

#include "TradeOffer.h"

TradeOffer::TradeOffer() {
}

TradeOffer::TradeOffer(int offerResources[NUM_RESOURCES], Player* player) {
    assertResources(offerResources, player);
    memcpy(offer, offerResources, sizeof (offer));
    offerer = player;
    completed = false;
}

TradeOffer::TradeOffer(Player* player) {
    offerer = player;
    memset(offer, 0, sizeof (offer));
    completed = false;
}

bool TradeOffer::acceptable(Player* player) {
    try {
        assertResources(offer, player, true);
    } catch (const char* err) {
        return false;
    }
    return true;
}

void TradeOffer::accept(Player* player) { // NULL player is bank
    assertResources(offer, offerer);
    if (player != NULL)
        assertResources(offer, player, true);

    for (int i = 0; i < NUM_RESOURCES; i++) {
        offerer->resources[i] += offer[i];

        if (player != NULL)
            player->resources[i] -= offer[i];
    }
    completed = true;
}

void TradeOffer::setResources(int set[NUM_RESOURCES]) {
    memcpy(offer, set, sizeof (offer));
}

int* TradeOffer::getResources() {
    return offer;
}

void TradeOffer::assertResources(int resources [NUM_RESOURCES], Player* player, bool reciever) {
    for (int i = 0; i < NUM_RESOURCES; i++) { // confirm players have right number of resources
        if (reciever ? player->resources[i] < resources[i] : player->resources[i] < -resources[i]) {
            throw "someone doesnt have enough resources!";
        }
    }
}

void TradeOffer::assertResources(int resources[NUM_RESOURCES], Player* player) {
    assertResources(resources, player, false);
}

TradeOffer::TradeOffer(const TradeOffer& orig) {
}

TradeOffer::~TradeOffer() {
}

