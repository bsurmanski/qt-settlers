/* 
 * File:   Board.h
 * Author: brandon
 *
 * Created on May 2, 2011, 8:03 PM
 */

#ifndef BOARD_H
#define	BOARD_H
#include <GL/gl.h>
#include "Tile.h"
#include "Robber.h"
#include "Seaport.h"

#define PI M_PI

#define NUM_RESOURCES 5

#define BOARDRADIUS 3 //TODO: if boardsize > 12, throws on L81. fix
#define TILE_SEPARATION 1.8
#define WATER_BORDER true
#define ISLANDS true
#define BRIDGES true
#define BOATS true
#define STARTING_RESOURCES true

#define Natasha <3

class Board {
public:
    Board();
    Board(const Board& orig);
    virtual ~Board();
    void Draw();
    void Update(int t);
    Tile* getClosestTile(Vector3f position);
    int getNumberOfTiles();
    bool moveRobber(int tile);
    Tile::CornerNode* occupyCorner(int tile, int corner);
    Tile::CornerNode* occupyCorner(Tile::CornerNode* corner);
    Tile::CornerNode* getDefaultNodeSelection();
    Vector2f rollDice();
    void generateGLDisplayList(GLuint index);

private:
    GLuint displayListIndex;
    GLuint numbersDisplayList;

    Tile** tiles;
    Robber* robber;
    Seaport** ports;
    int boardSize;
    int innerBoardSize;
    
    int numWaterTiles;
    int numDeserts;
    int numPorts;

    float getBorderSize();

    int* getScrambledChits();
    int* getScrambledResources(int deserts);
    int* getScrambledPorts(int ports);
    int indexOfMaxFromArray(int* array, int size);
    void scrambleIntArray(int* array, int size);
    void placePorts();
    void calculateNumberOfPorts();
};

#endif	/* BOARD_H */

