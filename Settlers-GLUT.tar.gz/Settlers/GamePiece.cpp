/* 
 * File:   GamePiece.cpp
 * Author: brandon
 * 
 * Created on May 2, 2011, 8:04 PM
 */

#include "GamePiece.h"
#include <GL/gl.h>

GamePiece::GamePiece() {
    model = NULL;
}

GamePiece::GamePiece(const GamePiece& orig) {
}

Vector3f GamePiece::getPosition(){
    return position;
}

GamePiece::~GamePiece() {
    if (model!=NULL)
    delete model;
}

