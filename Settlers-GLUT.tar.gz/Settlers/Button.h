/* 
 * File:   Button.h
 * Author: brandon
 *
 * Created on May 8, 2011, 9:52 PM
 */

#ifndef BUTTON_H
#define	BUTTON_H
#include "Sprite.h"
#include <string>
class Button {
public:
    Button();
    Button(const Button& orig);
    virtual ~Button();
    Vector2f getLocation();
    Vector2f getBounds();
    bool cursorInButton(int x, int y);
    void registerAction(void (*actionPtr)(void));
    void registerAction(void (*actionPtr)(int));
    void activate();
    void activate(int param);
    void Draw();
private:
    std::string text;
    void (*actionPtrVoid)();
    void (*actionPtrInt)(int);
    Vector2f location; // top left of button
    Vector2f bounds; //bounds of button
    Sprite stateUp;
};

#endif	/* BUTTON_H */

