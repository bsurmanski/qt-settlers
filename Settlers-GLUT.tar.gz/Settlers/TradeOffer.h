/* 
 * File:   TradeOffer.h
 * Author: brandon
 *
 * Created on May 18, 2011, 3:14 PM
 */

#ifndef TRADEOFFER_H
#define	TRADEOFFER_H
#include "Player.h"

#define NUM_RESOURCES 5

#define WOOD 0
#define SHEEP 1
#define WHEAT 2
#define BRICK 3
#define ROCK 4

class Player;
class TradeOffer {
public:
    TradeOffer();
    TradeOffer(int offer[NUM_RESOURCES], Player* player);
    TradeOffer(Player* player);
    TradeOffer(const TradeOffer& orig);
    
    void accept(Player* player);
    bool acceptable(Player* player);
    void setResources(int set[NUM_RESOURCES]);
    int* getResources();
    
    virtual ~TradeOffer();
private:
    
    void assertResources(int resources[NUM_RESOURCES], Player* player, bool reciever);
    void assertResources(int resources[NUM_RESOURCES], Player* player);
    int offer[NUM_RESOURCES];
    bool completed;
    Player* offerer;

};

#endif	/* TRADEOFFER_H */

